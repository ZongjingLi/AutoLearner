from .clevr4 import *
from .sprites import *
from .partnet import *
from .toy import *
from .ptr import *
from .acherus import *